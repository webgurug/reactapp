<?php 
header("Access-Control-Allow-Origin: *");
$rest_json = file_get_contents("php://input");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "reactutorials";

$jsonData = json_decode($rest_json, true);
//http_response_code(200);

print_r($jsonData);

$fname = $jsonData['fname'];
$lname = $jsonData['lname'];
$email = $jsonData['email'];
$msg   = $jsonData['message'];

if($fname !="" && $email !="")
{
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$query = "INSERT INTO `contact_us`(`fname`, `lname`, `email`, `message`) VALUES('$fname','$lname','$email','$msg')";

if ($conn->query($query) === TRUE) {
  echo json_encode(array("sucesmsg" => "Record Inserted Sucessfully."));
} else {
  //echo "Error: " . $query . "<br>" . $conn->error;
  echo json_encode(array("errormsg" => "There is Something Wrong."));
}
}
$conn->close();