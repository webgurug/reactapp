export { default as Navigation } from "./Navigation";
export { default as Footer } from "./Footer";
export { default as Home } from "./Home";
export { default as About } from "./About";
export { default as Blog } from "./Blog";
export { default as Singleview } from "./Singleview";
export { default as Contact } from "./Contact";