import React, { Component } from "react";
import axios from 'axios';
//import '../App.css';

class Contact extends React.Component{
	constructor(props) {
	  super(props);
		
	  this.state = {
		fields: {},
		errors: {}
	  }

	  this.state = {
		fname: '',
		lname: '',
		email: '',
		message: '',
		sucesmsg: '',
		error: null
	  }
	}
	handleFormSubmit = e => {
		e.preventDefault();
		console.log(this.state);

		if(this.state.fname !="" && this.state.email !=""){
		axios({
		  method: 'POST',
		  url: '/reactapps/reactwoo/send/contact/',
		  headers: {
			'Accept': 'application/json',
			'Content-Type': 'application/json'
		},
		  data: this.state
		})
		  .then(result => {
			console.log(result.data);
			this.setState({
				loading: true,
			    insertdata: result.data		
			})
		  }).catch(error => this.setState({ error: error.message }));
	  }else{
		  alert("All Fields Are Require.");
	  } }

	render(){
	  return(
		<div className="contact">
		  <div className="container">
			<div className="row align-items-center my-5">
			  <div className="col-lg-7">
				<img
				  className="img-fluid rounded mb-4 mb-lg-0"
				  src="http://placehold.it/900x400"
				  alt=""
				/>
			  </div>
			  <div className="col-lg-5">
				<h1 className="font-weight-light">Contact</h1>
				<p>
				  Lorem Ipsum is simply dummy text of the printing and typesetting
				  industry. Lorem Ipsum has been the industry's standard dummy text
				  ever since the 1500s, when an unknown printer took a galley of
				  type and scrambled it to make a type specimen book.
				</p>
			  </div>
			</div>		

			<form action="#" className="formClass">
			  <div className="form-group">
				<label>First Name</label>
				<input type="text" id="fname" name="firstname" className="form-control" placeholder="Your name.." value={this.state.fname} onChange={e => this.setState({ fname: e.target.value })} />
			  </div>
			  <div className="form-group">	
				<label>Last Name</label>
				<input type=" text" id="lname" name="lastname" className="form-control" placeholder="Your last name.." value={this.state.lname} onChange={e => this.setState({ lname: e.target.value })}	/>
				</div>	

			  <div className="form-group">
				<label>Email</label>
				<input type="email" id="email" name="email" className="form-control" placeholder="Your email" value={this.state.email} onChange={e => this.setState({ email: e.target.value })} />
			  </div>

			  <div className="form-group">	
				<label>Message</label>
				<textarea id="message" name="message" className="form-control" placeholder="Write something.." onChange={e => this.setState({ message: e.target.value })} value={this.state.message}
				></textarea>
			  </div>	

			  <input type="submit" className="btn btn-primary" onClick={e => this.handleFormSubmit(e)} value="Submit" />
				<div className="displayres" id="displayres"></div>
			
			  <div>
				{this.state.insertdata &&
					<div className="alert alert-success">Thank you for contact us.</div>
				}
			  </div>
			</form>
			
		  </div>
		</div>
	  );
	}
}
export default Contact;