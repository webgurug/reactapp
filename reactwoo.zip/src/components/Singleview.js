import React, {Component} from 'react';
import axios from 'axios';

class Singleview extends Component {
  constructor(props) {
    super(props);
    this.state = {
      post: {},
    };
    this.createMarkup = this.createMarkup.bind();
  }
  componentDidMount() {
    const slug = this.props.match.params.slug;
    axios
      .get(`http://localhost/reactapps/wpapp/wp-json/wp/v2/posts?slug=${slug}`)
      .then(post => {
        this.setState({
          post: post.data[0],
        });
      });
      //console.log("Respo==>",  this.state.post.data[0]);
  }

  createMarkup(html) {
    return {__html: html};
  }

  render() {
    let build;
    //console.log("Respo==>",  this.state.post);
    if (this.state.post.title) {
      build = (
        <div className="container mt-100 mt-60">
            <img src={this.state.post.featured_image_url} className="img-fluid rounded-top" alt="" />
          <h1>{this.state.post.title.rendered}</h1>
          <div
            dangerouslySetInnerHTML={this.createMarkup(
              this.state.post.content.rendered
            )} />
        </div>
      );
    } else {
      build = <div />;
    }
    return build;
  }
}

export default Singleview;