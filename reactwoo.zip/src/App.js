//import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Route, Link, Switch} from "react-router-dom";
import { Navigation, Footer, Home, About, Blog, Singleview, Contact } from "./components";

function App() {
  return (
    <div className="App">
      <Router>
        <Navigation />
          <Switch>
          <Route path="/" exact component={() => <Home />} />
          <Route path="/about" exact component={() => <About />} />
          <Route path="/contact" exact component={() => <Contact />} />
          <Route path="/blog" exact component={() => <Blog />} />
          <Route path="/:slug" component={Singleview} />
          
          </Switch>
      </Router>
    </div>
  );
}

export default App;


